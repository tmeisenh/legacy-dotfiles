These RELAX NG gammars were copied on 2005-09-06 from
http://www.w3.org/TR/2005/WD-xhtml2-20050527

The driver for the full schema is xhtml2.rng

Apache Forrest internal does not yet use all modules,
so our driver is xhtml2-forrest.rng
