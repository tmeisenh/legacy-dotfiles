These are the deprecated document-v10 DTDs. Please use the current
v20 DTDs instead. 
