There is a .htaccess in this directory.
Its purpose is to deliver DTDs and associated resources to some
impoverished XML tools that do not use the Catalog Entity Resolver.

These resources are made available on the forrest.apache.org website 
via an 'svn co' of this directory. See further info at ./index.html

FIXME: There are similar .htaccess at both
forrest.apache.org/dtd/ and forrest.apache.org/entity/
until we merge the entity sets into the /dtd/ directory.
